package be.vdab.cultuurhuis.controllers;

import be.vdab.cultuurhuis.services.GenreService;
import be.vdab.cultuurhuis.services.VoorstellingService;
import be.vdab.cultuurhuis.sessions.Mandje;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class IndexController {
    private final VoorstellingService voorstellingService;
    private final GenreService genreService;


    public IndexController(VoorstellingService voorstellingService, GenreService genreService) {
        this.voorstellingService = voorstellingService;
        this.genreService = genreService;
    }

    @GetMapping
    public ModelAndView voorstellingen() {
        ModelAndView modelAndView = new ModelAndView("index", "voorstellingen", voorstellingService.findAll());

        modelAndView.addObject("genres",genreService.findAll());
        return modelAndView;
    }
}
