package be.vdab.cultuurhuis.services;

import be.vdab.cultuurhuis.domain.Reservatie;

public interface ReservatieService {
    void create(Reservatie reservatie);
}
