package be.vdab.cultuurhuis.controllers;

import be.vdab.cultuurhuis.services.GenreService;
import be.vdab.cultuurhuis.sessions.Mandje;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/login")
public class LoginController {
    private final GenreService genreService;
    private final Mandje mandje;
    public LoginController(GenreService genreService, Mandje mandje) {
        this.genreService = genreService;
        this.mandje = mandje;
    }
    @GetMapping
    public ModelAndView login() {
        ModelAndView modelAndView = new ModelAndView("login");

        modelAndView.addObject("genres",genreService.findAll());
        return modelAndView;
    }

}
