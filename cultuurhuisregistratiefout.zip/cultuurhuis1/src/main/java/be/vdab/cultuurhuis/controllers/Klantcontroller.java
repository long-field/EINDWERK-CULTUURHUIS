package be.vdab.cultuurhuis.controllers;

import be.vdab.cultuurhuis.domain.Adres;
import be.vdab.cultuurhuis.domain.Klant;
import be.vdab.cultuurhuis.forms.NieuweKlantForm;
import be.vdab.cultuurhuis.services.KlantService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Controller
@RequestMapping("/klant")
public class Klantcontroller {
private KlantService klantService;

    public Klantcontroller(KlantService klantService) {
        this.klantService = klantService;
    }

    @GetMapping
    public ModelAndView nieuweKlant(){
        ModelAndView modelAndView = new ModelAndView("nieuweklant");
        modelAndView.addObject("nieuweklantform", new NieuweKlantForm(null,null,null,null,null,null,null,null,null));
                return modelAndView;
    }
    @GetMapping("/geregistreerd")
    public ModelAndView geregistreerd(){
        ModelAndView modelAndView = new ModelAndView("geregistreerd");
       return modelAndView;
    }
    @PostMapping()
    public ModelAndView registreer(@Valid NieuweKlantForm form, Errors errors, HttpServletRequest request, RedirectAttributes redirect) throws ServletException {
        Klant klant = new Klant(form.getVoornaam(), form.getFamilienaam(), new Adres(form.getStraat(), form.getHuisnr(), form.getPostcode(), form.getGemeente()),
                form.getGebruikersnaam(), new BCryptPasswordEncoder().encode(form.getPaswoord()));
        klantService.create(klant);

        request.login(form.getGebruikersnaam(), form.getPaswoord());
        return new ModelAndView("redirect:/klant/geregistreerd");
    }

}
