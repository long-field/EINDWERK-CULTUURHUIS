package be.vdab.cultuurhuis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CultuurhuisApplicationTests {

    @Test
    void contextLoads() {
    }

}
